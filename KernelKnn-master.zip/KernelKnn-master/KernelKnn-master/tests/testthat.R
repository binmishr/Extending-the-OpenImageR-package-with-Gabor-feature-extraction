library(testthat)
library(KernelKnn)

test_check("KernelKnn")
