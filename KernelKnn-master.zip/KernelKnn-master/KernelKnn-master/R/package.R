#' @useDynLib KernelKnn, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL